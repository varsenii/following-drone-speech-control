DEFAULT_CONFIDENCE_THRESHOLD = 0.5
DEMO_IMAGE = "images/demo.jpg"
MODEL = "model/MobileNetSSD_deploy.caffemodel"
PROTOTXT = "model/MobileNetSSD_deploy.prototxt.txt"
